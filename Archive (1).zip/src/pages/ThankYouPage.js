import React from "react";

const ThankYouPage = () => {
  return (
    <>
      <h1>Thanks for your query!</h1>
    </>
  );
};

export default ThankYouPage;
