import React from 'react'
import {Link} from 'react-router-dom'
import CourseListing from '../component/CourseListing'


const CourseListPage = () => {
  return (
    <CourseListing/>
  )
}

export default CourseListPage