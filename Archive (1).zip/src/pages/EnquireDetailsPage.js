import React from "react";
import EnquiryListing from "../component/EnquiryListing";

const EnquireDetailsPage = () => {
  return (
    <div>
      <EnquiryListing />
    </div>
  );
};

export default EnquireDetailsPage;
